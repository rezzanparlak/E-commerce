package ProductsInheritance;

public interface ProductInterface {
	public abstract void addVat() ;
}
